"""
TurboQuant Core Quantizer
==========================
The correct implementation of TurboQuant using Lloyd-Max codebooks.

Two variants (as described in the paper):

  TurboQuant_mse (default, use for KV cache):
    - Random rotation: x' = R @ x
    - Lloyd-Max quantize each coordinate of x' using the Beta codebook
    - Store: uint8 indices + float32 global norm
    - Dequantize: centroids[indices], then undo rotation
    - Quality: cosine sim 0.98+ at 3-bit, 0.995+ at 4-bit

Key numbers from the reference implementation (d=256):
  2-bit: cosine sim 0.940, IP corr 0.945, ~3.9x compression vs fp16
  3-bit: cosine sim 0.983, IP corr 0.984, ~2.8x compression vs fp16
  4-bit: cosine sim 0.995, IP corr 0.995, ~1.9x compression vs fp16

Storage layout (per vector):
  - indices: packed bits  →  ceil(dim * bits / 8) bytes
  - norm:    float32      →  4 bytes
  Total: ceil(dim * bits / 8) + 4 bytes

NOTE: Indices are stored packed (e.g. 3-bit uses 3 bits each, not 8).
This is what enables the 2–4x compression claimed in the README.
"""

import math
import numpy as np
from dataclasses import dataclass
from typing import Optional, List

from .codebook import (
    lloyd_max_codebook,
    build_boundaries,
    quantize_with_codebook,
    dequantize_with_codebook,
)


# ── Bit-packing helpers ────────────────────────────────────────────────────────

def _packed_bytes(dim: int, bits: int) -> int:
    """Number of bytes needed to store `dim` values of `bits` bits each."""
    return math.ceil(dim * bits / 8)


def pack_indices(indices: np.ndarray, bits: int) -> np.ndarray:
    """
    Pack an array of uint8 indices (values in [0, 2^bits)) into a
    tightly-packed byte array using `bits` bits per element.

    Parameters
    ----------
    indices : np.ndarray, shape (dim,), dtype uint8
        Values must be in range [0, 2^bits).
    bits : int
        Bits per element (2, 3, or 4).

    Returns
    -------
    packed : np.ndarray, dtype uint8, shape (ceil(dim*bits/8),)
    """
    assert bits in (2, 3, 4, 8), f"bits must be 2, 3, 4, or 8, got {bits}"
    if bits == 8:
        return indices.copy()

    dim = len(indices)
    n_bytes = _packed_bytes(dim, bits)
    packed = np.zeros(n_bytes, dtype=np.uint8)

    bit_pos = 0
    for i, val in enumerate(indices):
        byte_idx = bit_pos >> 3          # bit_pos // 8
        bit_off  = bit_pos & 7           # bit_pos % 8
        remaining = 8 - bit_off

        if remaining >= bits:
            packed[byte_idx] |= (int(val) & ((1 << bits) - 1)) << bit_off
        else:
            # Split across two bytes
            packed[byte_idx] |= (int(val) & ((1 << remaining) - 1)) << bit_off
            packed[byte_idx + 1] |= (int(val) >> remaining) & ((1 << (bits - remaining)) - 1)

        bit_pos += bits

    return packed


def unpack_indices(packed: np.ndarray, dim: int, bits: int) -> np.ndarray:
    """
    Unpack a tightly-packed byte array back to uint8 indices.

    Parameters
    ----------
    packed : np.ndarray, dtype uint8
    dim : int
        Number of elements to unpack.
    bits : int
        Bits per element.

    Returns
    -------
    indices : np.ndarray, shape (dim,), dtype uint8
    """
    assert bits in (2, 3, 4, 8), f"bits must be 2, 3, 4, or 8, got {bits}"
    if bits == 8:
        return packed[:dim].copy()

    mask = (1 << bits) - 1
    indices = np.zeros(dim, dtype=np.uint8)

    bit_pos = 0
    for i in range(dim):
        byte_idx = bit_pos >> 3
        bit_off  = bit_pos & 7
        remaining = 8 - bit_off

        if remaining >= bits:
            indices[i] = (int(packed[byte_idx]) >> bit_off) & mask
        else:
            lo = int(packed[byte_idx]) >> bit_off
            hi = int(packed[byte_idx + 1]) << remaining
            indices[i] = (lo | hi) & mask

        bit_pos += bits

    return indices


# ── Compressed vector ──────────────────────────────────────────────────────────

@dataclass
class CompressedVector:
    """
    TurboQuant compressed representation of a single vector.

    Attributes
    ----------
    packed : np.ndarray, dtype uint8
        Bit-packed Lloyd-Max quantization indices.
        Length = ceil(dim * bits / 8).
    norm : float
        Original vector norm (float32).
    dim : int
        Original vector dimension (needed for unpacking).
    bits : int
        Bits per element used for this vector.
    """
    packed: np.ndarray
    norm: float
    dim: int
    bits: int

    def nbytes(self) -> int:
        """Total bytes for this compressed vector."""
        return len(self.packed) + 4  # packed bytes + float32 norm


# ── TurboQuant ────────────────────────────────────────────────────────────────

class TurboQuant:
    """
    TurboQuant: near-optimal online vector quantizer.

    Uses a random orthogonal rotation followed by Lloyd-Max scalar quantization
    tuned to the Beta((d-1)/2, (d-1)/2) distribution that rotated coordinates follow.

    Parameters
    ----------
    dim : int
        Vector dimension (e.g., head_dim for KV cache, typically 64-256).
    bits : int
        Bits per dimension. Use 3 for aggressive, 4 for lossless. Default: 4.
    mode : str
        'mse'  - minimize reconstruction error (use for KV cache, default).
    seed : int
        Random seed for the rotation matrix.
    verbose : bool
        Print codebook build progress.

    Example
    -------
    >>> tq = TurboQuant(dim=128, bits=4)
    >>> key = np.random.randn(128).astype('float32')
    >>> c = tq.compress(key)
    >>> key_hat = tq.decompress(c)
    >>> print(np.dot(key, key_hat) / (np.linalg.norm(key) * np.linalg.norm(key_hat)))
    # Should be > 0.99 at 4-bit
    """

    def __init__(
        self,
        dim: int,
        bits: int = 4,
        mode: str = "mse",
        seed: int = 42,
        verbose: bool = False,
    ):
        self.dim = dim
        self.bits = bits
        self.mode = mode
        self.seed = seed

        # Build random orthogonal rotation matrix
        rng = np.random.default_rng(seed)
        G = rng.standard_normal((dim, dim)).astype(np.float32)
        Q, _ = np.linalg.qr(G)
        self.R = Q          # shape: (dim, dim), orthogonal
        self.R_T = Q.T      # precompute transpose for dequantization

        # Build Lloyd-Max codebook
        self.centroids = lloyd_max_codebook(dim=dim, bits=bits, verbose=verbose)
        self.boundaries = build_boundaries(self.centroids)

    # ── Compress / Decompress ─────────────────────────────────────────────────

    def compress(self, x: np.ndarray) -> CompressedVector:
        """Compress a vector using TurboQuant with bit-packing."""
        x = np.asarray(x, dtype=np.float32).ravel()
        assert len(x) == self.dim, f"Expected dim={self.dim}, got {len(x)}"

        norm = float(np.linalg.norm(x))
        if norm < 1e-9:
            packed = pack_indices(np.zeros(self.dim, dtype=np.uint8), self.bits)
            return CompressedVector(packed=packed, norm=0.0, dim=self.dim, bits=self.bits)

        x_unit = x / norm
        x_rot = self.R @ x_unit
        indices = quantize_with_codebook(x_rot, self.boundaries)
        packed = pack_indices(indices, self.bits)

        return CompressedVector(packed=packed, norm=norm, dim=self.dim, bits=self.bits)

    def decompress(self, c: CompressedVector) -> np.ndarray:
        """Reconstruct a vector from its compressed representation."""
        if c.norm < 1e-9:
            return np.zeros(self.dim, dtype=np.float32)

        indices = unpack_indices(c.packed, c.dim, c.bits)
        x_hat_rot = dequantize_with_codebook(indices, self.centroids)
        x_hat_unit = self.R_T @ x_hat_rot
        return (x_hat_unit * c.norm).astype(np.float32)

    def inner_product(self, q: np.ndarray, c: CompressedVector) -> float:
        """Compute inner product between a query and a compressed key."""
        q = np.asarray(q, dtype=np.float32).ravel()

        if c.norm < 1e-9:
            return 0.0

        q_rot = self.R @ q
        indices = unpack_indices(c.packed, c.dim, c.bits)
        k_hat_rot = dequantize_with_codebook(indices, self.centroids)
        ip = float(np.dot(q_rot, k_hat_rot)) * c.norm

        return ip

    # ── Batch operations ──────────────────────────────────────────────────────

    def compress_batch(self, X: np.ndarray) -> List[CompressedVector]:
        """Compress a batch of vectors."""
        X = np.asarray(X, dtype=np.float32)
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        X_unit = X / np.where(norms > 1e-9, norms, 1.0)

        X_rot = X_unit @ self.R.T
        all_indices = quantize_with_codebook(X_rot, self.boundaries)  # (N, dim) uint8

        result = []
        for i in range(len(X)):
            packed = pack_indices(all_indices[i], self.bits)
            result.append(CompressedVector(
                packed=packed,
                norm=float(norms[i, 0]),
                dim=self.dim,
                bits=self.bits,
            ))
        return result

    def decompress_batch(self, compressed: List[CompressedVector]) -> np.ndarray:
        """Decompress a list of CompressedVectors to (n, dim) array."""
        return np.stack([self.decompress(c) for c in compressed])

    def inner_product_batch(
        self, q: np.ndarray, compressed: List[CompressedVector]
    ) -> np.ndarray:
        """Compute inner products between one query and many compressed keys."""
        q = np.asarray(q, dtype=np.float32).ravel()
        q_rot = self.R @ q

        # Unpack all indices into (n, dim) array
        all_indices = np.stack([
            unpack_indices(c.packed, c.dim, c.bits) for c in compressed
        ])  # (n, dim) uint8
        all_norms = np.array([c.norm for c in compressed], dtype=np.float32)

        K_hat_rot = self.centroids[all_indices.astype(np.int32)]  # (n, dim)
        scores = (K_hat_rot @ q_rot) * all_norms

        return scores

    # ── Memory / stats ────────────────────────────────────────────────────────

    def bytes_per_vector(self) -> int:
        """
        Bytes used per compressed vector with bit-packing.
        = ceil(dim * bits / 8) for packed indices + 4 for float32 norm.
        """
        return _packed_bytes(self.dim, self.bits) + 4

    def compression_ratio(self, original_dtype_bytes: int = 2) -> float:
        """Compression ratio vs original storage (default fp16 = 2 bytes/elem)."""
        original_bytes = self.dim * original_dtype_bytes
        return original_bytes / self.bytes_per_vector()

    def effective_bits_per_element(self) -> float:
        """Effective bits used per coordinate (accounting for norm overhead)."""
        return (self.bytes_per_vector() * 8) / self.dim

    def __repr__(self) -> str:
        eff = self.effective_bits_per_element()
        return (
            f"TurboQuant(dim={self.dim}, bits={self.bits}, mode={self.mode!r}, "
            f"effective={eff:.2f} bits/elem, "
            f"compression={self.compression_ratio():.2f}x vs fp16)"
        )
