"""
TurboQuant PyTorch Backend
===========================
GPU-accelerated version of the core TurboQuant operations.
Works with torch.Tensor instead of np.ndarray.

This is the backend used by the HuggingFace cache integration.
It keeps everything in PyTorch so there's no CPU<->GPU transfer overhead.

Key operations:
  - compress(x): rotate + quantize + bit-pack → (packed_bytes, norms) tensors
  - decompress(packed, norms, dim): unpack + centroid gather + undo rotation
  - attention_scores(q, packed, norms): fused or fallback logits

FIX: compress() now returns bit-packed uint8 tensors (ceil(dim*bits/8) bytes
     per vector) instead of full uint8 indices (dim bytes per vector).
     This achieves the real 2–4x compression claimed in the README.

FIX: decompress undo-rotation was using wrong matrix: R instead of R^T.
     Correct: x_hat_unit = x_hat_rot @ R_T (where R_T = R^T).
"""

import math
import torch
import numpy as np
from typing import Tuple, Optional

from .codebook import lloyd_max_codebook, build_boundaries
from .triton_kernel import turboquant_attention_scores, is_triton_available


def _packed_bytes(dim: int, bits: int) -> int:
    """Bytes needed to store dim values of bits bits each."""
    return math.ceil(dim * bits / 8)


class TurboQuantTorch:
    """
    PyTorch-native TurboQuant quantizer with bit-packing.

    All operations run on the same device as the input tensors.
    Rotation matrix and codebook are registered as buffers so they
    move with .to(device) calls.

    Storage format (per vector):
        packed_indices: uint8 tensor, shape (..., ceil(dim*bits/8))
        norms:          float32 tensor, shape (...,)

    Parameters
    ----------
    dim : int
        Vector dimension.
    bits : int
        Bits per dimension (2, 3, or 4).
    seed : int
        Random seed for rotation matrix.
    verbose : bool
        Print codebook build progress.
    """

    def __init__(self, dim: int, bits: int = 4, seed: int = 42, verbose: bool = False):
        self.dim = dim
        self.bits = bits
        self.num_levels = 2 ** bits
        self.packed_dim = _packed_bytes(dim, bits)  # bytes per vector

        # ── Rotation matrix (orthogonal, from QR decomposition) ──────────────
        rng = np.random.default_rng(seed)
        G = rng.standard_normal((dim, dim)).astype(np.float32)
        Q, _ = np.linalg.qr(G)
        self._R   = torch.from_numpy(Q)      # (dim, dim)  — apply: x_rot = x @ R^T
        self._R_T = torch.from_numpy(Q.T)    # (dim, dim)  — undo:  x_hat = x_hat_rot @ R_T

        # ── Lloyd-Max codebook ────────────────────────────────────────────────
        centroids_np  = lloyd_max_codebook(dim=dim, bits=bits, verbose=verbose)
        boundaries_np = build_boundaries(centroids_np)
        self._centroids  = torch.from_numpy(centroids_np)    # (num_levels,)
        self._boundaries = torch.from_numpy(boundaries_np)   # (num_levels-1,)

        # Precompute bit-unpacking LUT on CPU (moved to device on .to())
        self._unpack_lut = self._build_unpack_lut()          # (256, 8) or similar

        self._device = torch.device("cpu")

    def _build_unpack_lut(self) -> Optional[torch.Tensor]:
        """
        For bits in {2, 4} build a lookup table so unpacking is a single
        gather instead of a Python loop. For bits=3 we fall back to the
        CPU numpy unpack (called once per batch, not per token).
        """
        if self.bits == 4:
            # Each byte → two 4-bit indices
            lut = np.zeros((256, 2), dtype=np.uint8)
            for b in range(256):
                lut[b, 0] = b & 0x0F
                lut[b, 1] = (b >> 4) & 0x0F
            return torch.from_numpy(lut)   # (256, 2)
        elif self.bits == 2:
            # Each byte → four 2-bit indices
            lut = np.zeros((256, 4), dtype=np.uint8)
            for b in range(256):
                lut[b, 0] = b & 0x03
                lut[b, 1] = (b >> 2) & 0x03
                lut[b, 2] = (b >> 4) & 0x03
                lut[b, 3] = (b >> 6) & 0x03
            return torch.from_numpy(lut)   # (256, 4)
        else:
            return None  # bits=3: use numpy fallback

    def to(self, device) -> "TurboQuantTorch":
        """Move all tensors to device (mirrors nn.Module.to())."""
        self._device     = torch.device(device)
        self._R          = self._R.to(device)
        self._R_T        = self._R_T.to(device)
        self._centroids  = self._centroids.to(device)
        self._boundaries = self._boundaries.to(device)
        if self._unpack_lut is not None:
            self._unpack_lut = self._unpack_lut.to(device)
        return self

    @property
    def device(self):
        return self._device

    # ── Compress ──────────────────────────────────────────────────────────────

    def compress(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Compress a batch of vectors with bit-packing.

        Parameters
        ----------
        x : Tensor, shape (N, dim) or (..., dim), any dtype

        Returns
        -------
        packed  : Tensor, shape (N, packed_dim), dtype uint8
                  Each row is bit-packed indices for one vector.
        norms   : Tensor, shape (N,), dtype float32
        """
        orig_shape = x.shape[:-1]
        N = x.shape[:-1].numel() if x.dim() > 1 else 1
        x = x.reshape(N, self.dim).to(dtype=torch.float32, device=self._device)

        # Extract norms
        norms = x.norm(dim=-1)                    # (N,)
        safe_norms = norms.clamp(min=1e-9)
        x_unit = x / safe_norms.unsqueeze(-1)     # (N, dim)

        # Random rotation: x_rot[i] = R @ x_unit[i]  ↔  x_unit @ R^T
        x_rot = x_unit @ self._R.T               # (N, dim)

        # Quantize to indices ∈ [0, 2^bits)
        indices = torch.bucketize(x_rot, self._boundaries)  # (N, dim) int32
        indices = indices.to(torch.uint8)

        # Bit-pack: (N, dim) uint8 → (N, packed_dim) uint8
        packed = self._pack_indices(indices)     # (N, packed_dim)

        return packed, norms.to(torch.float32)

    def _pack_indices(self, indices: torch.Tensor) -> torch.Tensor:
        """
        Pack (N, dim) uint8 indices into (N, packed_dim) uint8.
        Uses LUT for bits∈{2,4}, falls back to numpy for bits=3.
        """
        N = indices.shape[0]

        if self.bits == 4 and self._unpack_lut is not None:
            # Two 4-bit indices per byte
            # Reshape so we pair adjacent elements: (N, dim//2, 2)
            paired = indices.reshape(N, -1, 2)  # assumes dim is even
            lo = paired[:, :, 0].to(torch.int32)
            hi = paired[:, :, 1].to(torch.int32)
            packed = (lo | (hi << 4)).to(torch.uint8)   # (N, dim//2)
            return packed

        elif self.bits == 2 and self._unpack_lut is not None:
            # Four 2-bit indices per byte
            quads = indices.reshape(N, -1, 4)
            b0 = quads[:, :, 0].to(torch.int32)
            b1 = quads[:, :, 1].to(torch.int32)
            b2 = quads[:, :, 2].to(torch.int32)
            b3 = quads[:, :, 3].to(torch.int32)
            packed = (b0 | (b1 << 2) | (b2 << 4) | (b3 << 6)).to(torch.uint8)
            return packed

        else:
            # bits=3: numpy fallback (runs once per batch call, not per token)
            from .core import pack_indices as np_pack
            idx_np = indices.cpu().numpy()
            packed_list = [np_pack(idx_np[i], self.bits) for i in range(N)]
            packed_np = np.stack(packed_list)  # (N, packed_dim)
            return torch.from_numpy(packed_np).to(self._device)

    # ── Decompress ────────────────────────────────────────────────────────────

    def decompress(
        self, packed: torch.Tensor, norms: torch.Tensor
    ) -> torch.Tensor:
        """
        Reconstruct vectors from packed representation.

        Parameters
        ----------
        packed : Tensor, shape (N, packed_dim), uint8
        norms  : Tensor, shape (N,), float32

        Returns
        -------
        Tensor, shape (N, dim), float32
        """
        N = packed.shape[0]

        # Unpack to (N, dim) uint8
        indices = self._unpack_indices(packed, N)   # (N, dim) int64

        # Gather centroid values
        x_hat_rot = self._centroids[indices]         # (N, dim)

        # FIX: undo rotation — x_hat_unit = x_hat_rot @ R_T  (was: @ R, wrong)
        x_hat_unit = x_hat_rot @ self._R_T           # (N, dim)

        # Restore norms
        return x_hat_unit * norms.unsqueeze(-1)      # (N, dim)

    def _unpack_indices(self, packed: torch.Tensor, N: int) -> torch.Tensor:
        """Unpack (N, packed_dim) uint8 → (N, dim) int64."""
        if self.bits == 4:
            lo = packed.to(torch.int64) & 0x0F
            hi = (packed.to(torch.int64) >> 4) & 0x0F
            return torch.stack([lo, hi], dim=-1).reshape(N, self.dim)

        elif self.bits == 2:
            b0 = packed.to(torch.int64) & 0x03
            b1 = (packed.to(torch.int64) >> 2) & 0x03
            b2 = (packed.to(torch.int64) >> 4) & 0x03
            b3 = (packed.to(torch.int64) >> 6) & 0x03
            return torch.stack([b0, b1, b2, b3], dim=-1).reshape(N, self.dim)

        else:
            # bits=3: numpy fallback
            from .core import unpack_indices as np_unpack
            packed_np = packed.cpu().numpy()
            idx_list = [np_unpack(packed_np[i], self.dim, self.bits) for i in range(N)]
            idx_np = np.stack(idx_list).astype(np.int64)
            return torch.from_numpy(idx_np).to(self._device)

    # ── Attention scores ──────────────────────────────────────────────────────

    def attention_scores(
        self,
        query: torch.Tensor,        # (..., dim)
        packed: torch.Tensor,       # (seq_len, packed_dim) uint8
        k_norms: torch.Tensor,      # (seq_len,) float32
        scale: Optional[float] = None,
    ) -> torch.Tensor:
        """
        Compute attention logits between query and packed compressed keys.
        Uses Triton kernel on CUDA, PyTorch on CPU.

        Parameters
        ----------
        query   : Tensor (..., dim) — raw (unrotated) query
        packed  : Tensor (seq_len, packed_dim) uint8
        k_norms : Tensor (seq_len,) float32
        scale   : float, default 1/sqrt(dim)

        Returns
        -------
        logits : Tensor (..., seq_len)
        """
        if scale is None:
            scale = self.dim ** -0.5

        query = query.to(dtype=torch.float32, device=self._device)
        seq_len = packed.shape[0]

        # Decompress keys fully (needed for batched query case)
        k_hat = self.decompress(packed, torch.ones(seq_len, device=self._device))
        # (seq_len, dim) — norms applied separately via k_norms broadcast

        # Pre-rotate query
        q_rot = query @ self._R.T  # (..., dim)

        if q_rot.dim() == 1:
            # Single query: try Triton kernel with unpacked centroids path
            k_indices = self._unpack_indices(packed, seq_len)  # (seq_len, dim) int64
            k_indices_u8 = k_indices.to(torch.uint8)
            return turboquant_attention_scores(
                q_rot, k_indices_u8, k_norms, self._centroids, scale,
                use_triton=True,
            )
        else:
            # Batched: matmul path
            # k_hat already has centroids gathered but norms=1; multiply norms
            logits = (q_rot @ k_hat.T) * scale         # (..., seq_len)
            logits = logits * k_norms.unsqueeze(0)     # broadcast norms
            return logits

    # ── Memory stats ──────────────────────────────────────────────────────────

    def bytes_per_vector(self) -> int:
        """Bytes used per compressed vector: packed indices + float32 norm."""
        return self.packed_dim + 4

    def compression_ratio(self, original_dtype_bytes: int = 2) -> float:
        return (self.dim * original_dtype_bytes) / self.bytes_per_vector()

    def __repr__(self) -> str:
        ratio = self.compression_ratio()
        return (
            f"TurboQuantTorch(dim={self.dim}, bits={self.bits}, "
            f"packed_dim={self.packed_dim}, "
            f"compression={ratio:.2f}x vs fp16, "
            f"device={self._device}, "
            f"triton={'✓' if is_triton_available() else '✗ (PyTorch fallback)'})"
        )
