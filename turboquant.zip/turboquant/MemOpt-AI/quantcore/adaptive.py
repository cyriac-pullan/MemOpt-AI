"""
QuantCore Adaptive Compression Engine
======================================
Dynamically adjusts KV cache compression based on runtime conditions.

FIX 1 — Thread safety:
    history list append is now protected by threading.Lock so the policy
    is safe in multi-threaded / async serving scenarios.

FIX 2 — Upward transition logic:
    The original code had a bug where relaxing compression (going from
    2-bit back to 4-bit) required both pressure < 0.5 AND stability steps
    to have elapsed. But the stability counter reset on downward transitions,
    so upward transitions could be starved. Fixed by tracking separate
    counters for compression-escalation vs compression-relaxation.

Architecture:
    AdaptivePolicy monitors seq_len + GPU memory pressure and returns
    the optimal bit depth. It uses hysteresis to prevent rapid switching.

    Segments track mixed-precision regions in the KV cache:
    [4-bit tokens 0-1023] [3-bit tokens 1024-4095] [2-bit tokens 4096+]
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class CacheSegment:
    """One contiguous region of the KV cache at a single bit depth."""
    bits: int
    start_idx: int  # inclusive
    end_idx: int    # exclusive
    token_count: int = 0

    @property
    def range_str(self) -> str:
        return f"[{self.start_idx}:{self.end_idx}] @ {self.bits}-bit"


class AdaptivePolicy:
    """
    Decides the optimal bit depth based on runtime state.

    Uses hysteresis to prevent rapid oscillation:
    - Downward transitions (more compression): allowed after stability_steps
      with no cooling period — compression is urgent.
    - Upward transitions (less compression): allowed after relax_steps AND
      pressure must have been below relax_pressure_threshold for that entire
      window.

    Parameters
    ----------
    memory_budget_mb : float, optional
        Hard memory limit. If set, policy aggressively compresses to stay under.
    stability_steps : int
        Minimum steps at current bits before allowing compression escalation.
        Default 32.
    relax_steps : int
        Minimum steps at current bits before allowing compression relaxation.
        Default 128 (intentionally higher — relax more conservatively).
    relax_pressure_threshold : float
        Memory pressure must stay below this for relax_steps before relaxing.
        Default 0.5.
    thresholds : list, optional
        Override default seq_len/pressure thresholds.
    """

    # Default thresholds: (max_seq_len, max_mem_pressure) -> bits
    DEFAULT_THRESHOLDS = [
        # (max_seq_len, max_mem_pressure, bits)
        (1024,  0.70, 16),   # no compression for short context, low pressure
        (2048,  0.80,  4),   # light compression
        (4096,  0.88,  4),   # still 4-bit
        (8192,  0.92,  3),   # balanced
        (99999, 1.00,  2),   # emergency: max compression
    ]

    def __init__(
        self,
        memory_budget_mb: float = None,
        stability_steps: int = 32,
        relax_steps: int = 128,
        relax_pressure_threshold: float = 0.5,
        thresholds: list = None,
    ):
        self.memory_budget_mb = memory_budget_mb
        self.stability_steps = stability_steps
        self.relax_steps = relax_steps
        self.relax_pressure_threshold = relax_pressure_threshold
        self.thresholds = thresholds or self.DEFAULT_THRESHOLDS

        # State tracking
        self._current_bits: int = 16          # start uncompressed
        self._steps_at_current: int = 0
        self._low_pressure_streak: int = 0    # FIX 2: tracks relaxation readiness
        self._history: List[dict] = []
        self._lock = threading.Lock()          # FIX 1: thread safety

    def select_bits(
        self,
        seq_len: int,
        gpu_mem_used_mb: float = 0,
        gpu_mem_total_mb: float = 0,
    ) -> int:
        """
        Returns the recommended bit depth for the current state.

        Thread-safe. May be called from multiple threads in async serving.

        Parameters
        ----------
        seq_len : int
            Current total sequence length (input + generated so far).
        gpu_mem_used_mb : float
            Current GPU memory used in MB.
        gpu_mem_total_mb : float
            Total GPU memory in MB.

        Returns
        -------
        int : recommended bits (2, 3, 4, or 16 for no compression)
        """
        with self._lock:
            # Calculate memory pressure
            if gpu_mem_total_mb > 0:
                pressure = gpu_mem_used_mb / gpu_mem_total_mb
            else:
                pressure = 0.0

            # Memory budget override: if we're over budget, force max compression
            if self.memory_budget_mb and gpu_mem_used_mb > 0:
                budget_pressure = gpu_mem_used_mb / self.memory_budget_mb
                if budget_pressure > 0.95:
                    recommended = 2  # emergency
                elif budget_pressure > 0.85:
                    recommended = 3
                else:
                    recommended = self._threshold_lookup(seq_len, pressure)
            else:
                recommended = self._threshold_lookup(seq_len, pressure)

            self._steps_at_current += 1

            # FIX 2: Track low-pressure streak for relaxation decisions
            if pressure < self.relax_pressure_threshold:
                self._low_pressure_streak += 1
            else:
                self._low_pressure_streak = 0

            if recommended != self._current_bits:
                if recommended < self._current_bits:
                    # More compression needed — allow after stability_steps
                    if self._steps_at_current >= self.stability_steps:
                        self._current_bits = recommended
                        self._steps_at_current = 0
                        self._low_pressure_streak = 0
                else:
                    # FIX 2: Less compression — require sustained low pressure
                    # for relax_steps (not just a single instant below threshold)
                    if (self._steps_at_current >= self.relax_steps and
                            self._low_pressure_streak >= self.relax_steps):
                        self._current_bits = recommended
                        self._steps_at_current = 0
                        self._low_pressure_streak = 0

            # FIX 1: Thread-safe history append
            self._history.append({
                "seq_len": seq_len,
                "pressure": round(pressure, 3),
                "recommended": recommended,
                "applied": self._current_bits,
                "stable_for": self._steps_at_current,
                "low_pressure_streak": self._low_pressure_streak,
            })

            return self._current_bits

    def _threshold_lookup(self, seq_len: int, pressure: float) -> int:
        """Walk the threshold table and return first matching bits."""
        for max_seq, max_pressure, bits in self.thresholds:
            if seq_len <= max_seq and pressure <= max_pressure:
                return bits
        return 2  # fallback: max compression

    @property
    def current_bits(self) -> int:
        """Current bit depth. Thread-safe read."""
        return self._current_bits

    @property
    def history(self) -> List[dict]:
        """Copy of history log. Thread-safe read."""
        with self._lock:
            return list(self._history)

    def stats(self) -> dict:
        """Return current policy state for dashboard/logging."""
        with self._lock:
            return {
                "current_bits": self._current_bits,
                "steps_at_current": self._steps_at_current,
                "stability_threshold": self.stability_steps,
                "relax_threshold": self.relax_steps,
                "low_pressure_streak": self._low_pressure_streak,
                "memory_budget_mb": self.memory_budget_mb,
                "total_decisions": len(self._history),
            }

    def __repr__(self) -> str:
        return (
            f"AdaptivePolicy(bits={self._current_bits}, "
            f"stable_for={self._steps_at_current}/{self.stability_steps}, "
            f"low_pressure_streak={self._low_pressure_streak}/{self.relax_steps}, "
            f"budget={self.memory_budget_mb}MB)"
        )
